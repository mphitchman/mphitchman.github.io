Sketchpad Tools
Put the following file in the Tool Folder of your Sketchpad folder (text_tools.gsp)
Then reload Sketchpad to access tools relevant to the constructions in the text 

Chapter 1
	Exercise 1.3.1 � Coneland (coneland.gsp)
	Exercise 1.3.2 � Saddleland (saddleland.gsp)

Chapter 3
	Section 3.2 - Inversion (inversion_intro.gsp)
	Theorem 3.2.10 Inversion is conformal (inversion_conformal.gsp)
	Theorem 3.4.8 The Fundamental Theorem of Mobius Transformations (Mob1_0_infinity.gsp)
	Section 3.5 - Type I and II clines (typeIandII.gsp)
	Section 3.5  Mobius transformations determined by 2 inversions (mobtwoinversions.gsp)

Chapter 5
	Section 5.1 - Parallalel displacement (paralleldisplacement.gsp)
	Section 5.1 � hyperbolic translation (hyperbolictranslation.gsp)
	Section 5.1 � hyperbolic rotation (hyperbolicrotation.gsp)
	Example 5.1.8 - Moving an �M� around in the hyperbolic plane (Move_the_M.gsp)
	Definition 5.2.10 - Constructing a hyperbolic circle (hypcircle.gsp)
	Figure 5.3.13 The hyperbolic circle through 3 points, perhaps (hypcirclethrough3pts.gsp)
	Exercise 5.4.4 - All ideal triangles are congruent (ideal_triangle.gsp)
	Theorem 5.4.21 - Right angled hexagons (rightanglehexagon.gsp)
 
Chapter 6
	Section 6.1 - A look at antipodal points (antipodal_points.gsp)
	Sections 6.2 and 6.3 - Figures in elliptic space (elliptic_figures.gsp)

Chapter 7
	Example 7.7.9 and Exercise 7.7.1 - H1 as a quotient of the Euclidean plane, with Dirichlet domains (H1Dirichlet.gsp)
	Section 7.7 The space C2 as a quotient of the Euclidean plane (C2quotient.gsp)
	Exercise 7.7.2 - C3 as a quotient of the hyperbolic plane, with Dirichlet domain (C3Dirichlet.gsp)
	Exercise 7.7.4 The Dirichlet domain of an observer in C2 varies from point to point (C2Dirichlet.gsp)
